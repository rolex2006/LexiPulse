# LexiPulse Pi

30-second Web3 & online-safety speed arena for Pi Network (Pi Next hackathon entry).
Arabic + English (RTL), real Pi sign-in, real Pi payments, server-checked scores.

**The problem it addresses:** phishing and fake-token scams hit new crypto users hardest. LexiPulse Pi teaches the terms that protect them (passphrase, phishing, rug pull, Ponzi scheme, escrow...) in short daily sprints, with a streak and a fair ranking that bring players back.

## What the app does

- **Two 30s game modes**: Term Flash Match and Paradox Decoder.
- **Server-authoritative scoring**: questions, timing and points are computed on the server; the browser only sends answers.
- **Real ranking**: leaderboard of real signed-in players (no fake names). Daily streak for retention.
- **Pro Pass (0.15 π)**: a real Pi payment (approve → complete → verify on the server) that unlocks 8 expert terms and a PRO badge. It does **not** multiply scores.
- **Guest mode** works in a normal browser (PiNet); sign-in and payments need Pi Browser.
- **Honest rewards model**: LexiPoints are ranking points only; there is no cash-out to Pi.

## Pi Next conditions checklist (from minepi.com/pi-next)

Re-check the official page before you submit; rules can change.

| Requirement | Status |
|---|---|
| Register for Pi Next in the Developer Web Console (Hackathon tab); **every team member must register**; only **one** member submits each app | **You** |
| Up to 3 app entries; registering alone does not enter an app | **You** |
| App follows the **Mainnet Listing Requirements** and gives real utility to Pi users | Partly: read the listing requirements and check each one |
| Integrates **Pi Authentication** and **Pi payments** | Done (`/api/auth`, `/api/payments/*`) |
| **PiNet integration** | **You**: configure your PiNet address in the Developer Console; guest mode already works in a regular browser |
| **English app name** | `LexiPulse Pi`. Check Pi's trademark guidelines on using "Pi" in a name; if in doubt, submit it as "LexiPulse" |
| **Logo following Pi's trademark guidelines** | `public/logo.svg` is an original design (no Pi logo). Export a PNG and check it against the guidelines |
| **Accurate English description** | You write it (see the suggested text below) |
| **Preview images** of the interface | **You**: take screenshots in Pi Browser (Arena, ranking, Pro Pass, Arabic/RTL) |
| **Privacy policy** | `public/privacy.html` (EN + AR). **Replace `YOUR-EMAIL@example.com` with your real contact email** |
| **Demo video, 3 minutes or less, public** (e.g. YouTube), link in the form | **You** (script below) |
| Final submission through the Developer Web Console with all team members listed | **You**, before **Tue Jan 5, 2027, 11:59 PM PT** (Wed Jan 6, 07:59 UTC) |
| Optional midpoint submission (details are emailed to registered participants) | Optional, for early visibility and feedback |

How judges score the app: alignment with the Mainnet Listing Guidelines, Pi utility and community needs, technical completeness and innovation, UI/UX and accessibility, long-term utility, uniqueness. The Community Engagement awards also look at real user engagement and retention, so invite players early.

### Suggested app description (English)

> LexiPulse Pi helps Pioneers protect themselves from crypto scams. Play 30-second sprints to master Web3 and online-safety terms, build a daily streak, climb the ranking, and unlock expert terms with the Pro Pass paid in Pi. Available in English and Arabic.

### Demo video script (about 2:30)

1. **What it is (0:00–0:20):** "LexiPulse Pi teaches Web3 and online-safety terms in 30-second sprints."
2. **Problem and audience (0:20–0:45):** new Pioneers and crypto beginners, who are the main targets of phishing and fake-token scams.
3. **Pi sign-in (0:45–1:05):** open in Pi Browser, tap **Sign In**, show the username and rank.
4. **Walkthrough (1:05–1:50):** play a Flash Match sprint (combo, summary), then a Paradox Decoder round; show Insights (missed terms come back more often); switch to Arabic to show RTL.
5. **Pi payments (1:50–2:15):** open **Pass**, buy the Pro Pass with Pi, show the unlocked terms and the PRO badge on **Ranks**.
6. **Close (2:15–2:30):** real ranking, daily streak, fair server-side scoring.

## Run locally

```bash
npm install
ALLOW_DEV_LOGIN=true npm start     # then open http://localhost:3000
```

`ALLOW_DEV_LOGIN=true` gives a local test login so you can try ranked play outside Pi Browser. It is ignored when `NODE_ENV=production`. Payments can only be tested inside Pi Browser.

## Configuration (environment variables, see `.env.example`)

| Variable | Purpose |
|---|---|
| `PI_API_KEY` | Your app's API key from the Developer Console. Required for payments. |
| `SESSION_SECRET` | Long random string (`openssl rand -hex 32`). Required in production. |
| `PI_VALIDATION_KEY` | Domain validation key, served at `/validation-key.txt`. |
| `PI_SANDBOX` | `true` for sandbox/testnet, `false` for Mainnet. |
| `PRO_PRICE_PI` | Pro Pass price in Pi (default 0.15). |
| `DAILY_POINT_CAP` | Max ranking points per player per UTC day (default 3000). |
| `DATA_DIR` | Folder for the JSON database. Use a persistent disk. |

## Deploy

1. Deploy this folder to any Node 18+ host (Render, Railway, Fly.io, a VPS...). Set the variables above and attach a persistent disk for `DATA_DIR`.
2. In the Pi Developer Console register the app with your HTTPS URL, copy the API key into `PI_API_KEY` and the validation key into `PI_VALIDATION_KEY`.
3. Test sign-in and a Pro Pass purchase in sandbox mode, then switch `PI_SANDBOX=false` for Mainnet.
4. Submit the Mainnet listing for review (it does not need to be approved before you enter Pi Next), save the demo video link, then enter the app in Pi Next.

## Known limitations

- Anti-cheat is basic: server-side timing, a minimum human reaction time, one question at a time and a daily point cap. The term list is public, so a determined bot could still answer correctly. This is acceptable because points have no cash value.
- Storage is a JSON file. For real traffic, move to PostgreSQL or SQLite.
- The page uses the Tailwind CDN for simplicity. For production, compile Tailwind to a static CSS file.
- Pi App-to-User payments (sending Pi to players) are intentionally not used.
