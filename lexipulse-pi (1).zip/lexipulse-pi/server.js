'use strict';

/**
 * LexiPulse Pi - backend
 *  - Verifies Pi sign-in with the Pi Platform API (/me)
 *  - Real Pi payments: approve -> complete -> grant, with server-side checks
 *  - Server-authoritative 30s sprints (scores are computed here, not in the browser)
 *  - Real leaderboard + per-user progress (JSON file store; swap for a DB in production)
 */

const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const TERMS = require('./terms');

/* ------------------------------ config ------------------------------ */
const PORT = Number(process.env.PORT) || 3000;
const PI_API_KEY = process.env.PI_API_KEY || '';
const PI_API_BASE = process.env.PI_API_BASE || 'https://api.minepi.com/v2';
const PI_SANDBOX = process.env.PI_SANDBOX !== 'false'; // default true (testnet/sandbox)
const PRO_PRICE = Number(process.env.PRO_PRICE_PI) || 0.15;
const DAILY_POINT_CAP = Number(process.env.DAILY_POINT_CAP) || 3000;
const DEV_LOGIN = process.env.ALLOW_DEV_LOGIN === 'true' && process.env.NODE_ENV !== 'production';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

let SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET) {
  SESSION_SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('[warn] SESSION_SECRET is not set: sign-ins will reset on every restart.');
}
if (!PI_API_KEY) console.warn('[warn] PI_API_KEY is not set: Pi payments are disabled.');

const SPRINT_MS = 30000;
const GRACE_MS = 2500;        // network allowance after the 30s
const MIN_REACTION_MS = 350;  // faster than this is not humanly credible -> no points
const FEEDBACK_MS = 300;      // client shows the next question after this delay

const TERM_BY_ID = new Map(TERMS.map(t => [t.id, t]));

/* ------------------------------ storage ----------------------------- */
const DB_FILE = path.join(DATA_DIR, 'db.json');
let db = { users: {}, payments: {} };
try {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
} catch (e) { /* first run */ }
db.users = db.users || {};
db.payments = db.payments || {};

let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    const tmp = DB_FILE + '.tmp';
    fs.writeFile(tmp, JSON.stringify(db), err => {
      if (!err) fs.rename(tmp, DB_FILE, () => {});
    });
  }, 400);
}
process.on('SIGTERM', () => { try { fs.writeFileSync(DB_FILE, JSON.stringify(db)); } catch (e) {} process.exit(0); });

const todayKey = () => new Date().toISOString().slice(0, 10);

function upsertUser(uid, username) {
  let u = db.users[uid];
  if (!u) {
    u = db.users[uid] = {
      uid, username: username || 'pioneer', score: 0, pro: false, streak: 0, lastPlay: '',
      dayKey: '', dayPoints: 0, mastered: [], weak: [], reactions: [], ledger: [], createdAt: Date.now()
    };
  } else if (username && u.username !== username) {
    u.username = username;
  }
  save();
  return u;
}

function pushLedger(u, entry) {
  u.ledger.unshift(Object.assign({ ts: Date.now() }, entry));
  if (u.ledger.length > 50) u.ledger.length = 50;
}

function rankOf(u) {
  let r = 1;
  for (const o of Object.values(db.users)) if (o.score > u.score) r++;
  return r;
}

function publicMe(u) {
  return {
    username: u.username, score: u.score, pro: !!u.pro, streak: u.streak || 0,
    rank: u.score > 0 ? rankOf(u) : null,
    mastered: u.mastered, weak: u.weak, reactions: u.reactions, ledger: u.ledger.slice(0, 30)
  };
}

function awardPoints(u, pts) {
  const day = todayKey();
  if (u.dayKey !== day) { u.dayKey = day; u.dayPoints = 0; }
  const allowed = Math.max(0, Math.min(pts, DAILY_POINT_CAP - u.dayPoints));
  u.dayPoints += allowed;
  u.score += allowed;
  return { allowed, capped: allowed < pts };
}

function updateStreak(u) {
  const today = todayKey();
  if (u.lastPlay === today) return;
  const y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
  u.streak = u.lastPlay === y ? (u.streak || 0) + 1 : 1;
  u.lastPlay = today;
}

const addUnique = (arr, v) => { if (!arr.includes(v)) arr.push(v); };
const removeVal = (arr, v) => { const i = arr.indexOf(v); if (i >= 0) arr.splice(i, 1); };

/* ------------------------------ sessions ---------------------------- */
function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return body + '.' + sig;
}
function verify(token) {
  if (typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const exp = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig), b = Buffer.from(exp);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  } catch (e) { return null; }
}
function readUser(req) {
  const h = req.get('authorization') || '';
  if (!h.startsWith('Bearer ')) return null;
  const p = verify(h.slice(7));
  return p && db.users[p.uid] ? db.users[p.uid] : null;
}
const optionalAuth = (req, res, next) => { req.user = readUser(req); next(); };
const requireAuth = (req, res, next) => {
  req.user = readUser(req);
  if (!req.user) return res.status(401).json({ error: 'unauthorized' });
  next();
};
const issueSession = u => sign({ uid: u.uid, exp: Date.now() + 30 * 864e5 });

/* ------------------------------ helpers ----------------------------- */
const hits = new Map();
function rateLimit(name, max, windowMs) {
  return (req, res, next) => {
    const key = name + ':' + req.ip;
    const now = Date.now();
    const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
    if (arr.length >= max) return res.status(429).json({ error: 'rate_limited' });
    arr.push(now);
    hits.set(key, arr);
    next();
  };
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > 120000) hits.delete(k);
}, 60000).unref();

function shuffle(a) {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function piFetch(pathname, { method = 'GET', auth, body } = {}) {
  const res = await fetch(PI_API_BASE + pathname, {
    method,
    headers: { Authorization: auth, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch (e) { data = text; }
  if (!res.ok) {
    const err = new Error('Pi API ' + res.status);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}
const piKey = () => 'Key ' + PI_API_KEY;
const sameAmount = (a, b) => Math.abs(Number(a) - Number(b)) < 1e-7;
const validId = s => typeof s === 'string' && /^[\w-]{6,128}$/.test(s);

const requirePiKey = (req, res, next) =>
  PI_API_KEY ? next() : res.status(503).json({ error: 'payments_disabled' });

/* ------------------------------- app -------------------------------- */
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(express.json({ limit: '20kb' }));
app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('Referrer-Policy', 'no-referrer');
  next();
});

// Pi domain validation (value comes from the Pi Developer Portal)
app.get('/validation-key.txt', (req, res) => {
  if (!process.env.PI_VALIDATION_KEY) return res.status(404).end();
  res.type('text/plain').send(process.env.PI_VALIDATION_KEY);
});
app.get('/healthz', (req, res) => res.json({ ok: true }));

app.get('/api/config', (req, res) => {
  res.json({ sandbox: PI_SANDBOX, proPricePi: PRO_PRICE, paymentsEnabled: !!PI_API_KEY, devLogin: DEV_LOGIN });
});

/* ------------------------------- auth ------------------------------- */
app.post('/api/auth', rateLimit('auth', 20, 60000), async (req, res) => {
  const accessToken = req.body && req.body.accessToken;
  if (typeof accessToken !== 'string' || accessToken.length < 10 || accessToken.length > 4096) {
    return res.status(400).json({ error: 'bad_request' });
  }
  try {
    const me = await piFetch('/me', { auth: 'Bearer ' + accessToken });
    if (!me || !me.uid) throw new Error('no uid');
    const u = upsertUser(me.uid, me.username);
    res.json({ session: issueSession(u), me: publicMe(u) });
  } catch (e) {
    res.status(401).json({ error: 'pi_auth_failed' });
  }
});

// Local development only (disabled in production and unless ALLOW_DEV_LOGIN=true)
if (DEV_LOGIN) {
  app.post('/api/dev-login', rateLimit('dev', 20, 60000), (req, res) => {
    const name = String((req.body && req.body.username) || 'dev_player').replace(/[^\w]/g, '').slice(0, 20) || 'dev_player';
    const u = upsertUser('dev-' + name, name);
    res.json({ session: issueSession(u), me: publicMe(u) });
  });
}

app.get('/api/me', requireAuth, (req, res) => res.json({ me: publicMe(req.user) }));

/* ------------------------------- terms ------------------------------ */
app.get('/api/terms', optionalAuth, (req, res) => {
  const unlocked = !!(req.user && req.user.pro);
  const visible = TERMS.filter(t => !t.pro || unlocked);
  res.json({
    terms: visible.map(({ id, cat, pro, termEn, termAr, defEn, defAr }) => ({ id, cat, pro, termEn, termAr, defEn, defAr })),
    lockedCount: TERMS.length - visible.length
  });
});

/* ----------------------------- leaderboard -------------------------- */
app.get('/api/leaderboard', optionalAuth, (req, res) => {
  const ranked = Object.values(db.users).filter(u => u.score > 0).sort((a, b) => b.score - a.score);
  const top = ranked.slice(0, 20).map((u, i) => ({ rank: i + 1, username: u.username, score: u.score, pro: !!u.pro }));
  const me = req.user && req.user.score > 0 ? { rank: rankOf(req.user), username: req.user.username, score: req.user.score, pro: !!req.user.pro } : null;
  res.json({ top, me });
});

/* ------------------------------ sprints ----------------------------- */
const sprints = new Map();
setInterval(() => {
  const cutoff = Date.now() - 5 * 60000;
  for (const [id, sp] of sprints) if (sp.startedAt < cutoff) sprints.delete(id);
}, 60000).unref();

function pickTerm(pool, weak, lastId) {
  const weights = pool.map(t => (t.id === lastId ? 0 : weak.has(t.id) ? 3 : 1));
  const total = weights.reduce((a, b) => a + b, 0);
  if (!total) return pool[0];
  let r = Math.random() * total;
  for (let i = 0; i < pool.length; i++) { r -= weights[i]; if (r < 0) return pool[i]; }
  return pool[pool.length - 1];
}

function newQuestion(sp, delayMs) {
  const term = pickTerm(sp.pool, sp.weak, sp.cur ? sp.cur.termId : null);
  sp.seq += 1;
  const q = { seq: sp.seq, termId: term.id, issuedAt: Date.now() + (delayMs || 0) };
  const out = { seq: q.seq, cat: term.cat, termEn: term.termEn, termAr: term.termAr };
  if (sp.mode === 'flash') {
    const others = shuffle(sp.pool.filter(t => t.id !== term.id)).slice(0, 2);
    out.options = shuffle([term].concat(others)).map(t => ({ id: t.id, en: t.defEn, ar: t.defAr }));
  } else {
    q.truth = Math.random() > 0.5;
    out.statementEn = q.truth ? term.defEn : term.trapEn;
    out.statementAr = q.truth ? term.defAr : term.trapAr;
  }
  sp.cur = q;
  return out;
}

function endSprint(sp, user) {
  if (sp.summary) return sp.summary;
  sp.ended = true;
  const avg = sp.reactions.length ? Math.round(sp.reactions.reduce((a, b) => a + b, 0) / sp.reactions.length) : 0;
  sp.summary = {
    points: sp.points, total: sp.total, correct: sp.correct,
    accuracy: sp.total ? Math.round((sp.correct / sp.total) * 100) : 0, avgMs: avg
  };
  if (user && sp.total > 0) {
    updateStreak(user);
    pushLedger(user, { t: 'sprint', mode: sp.mode, amt: sp.points });
    save();
  }
  return sp.summary;
}

app.post('/api/sprint/start', optionalAuth, rateLimit('sprint', 60, 60000), (req, res) => {
  const mode = req.body && req.body.mode;
  if (mode !== 'flash' && mode !== 'paradox') return res.status(400).json({ error: 'bad_mode' });
  const pool = TERMS.filter(t => !t.pro || (req.user && req.user.pro));
  const sp = {
    id: crypto.randomBytes(12).toString('hex'),
    uid: req.user ? req.user.uid : null,
    mode, startedAt: Date.now(), seq: 0, cur: null,
    points: 0, total: 0, correct: 0, combo: 1, reactions: [],
    pool, weak: new Set(req.user ? req.user.weak : []), ended: false, summary: null
  };
  sprints.set(sp.id, sp);
  res.json({ sprintId: sp.id, durationMs: SPRINT_MS, question: newQuestion(sp, 0) });
});

app.post('/api/sprint/answer', optionalAuth, rateLimit('answer', 600, 60000), (req, res) => {
  const { sprintId, seq, answer } = req.body || {};
  const sp = sprints.get(sprintId);
  if (!sp) return res.status(404).json({ error: 'sprint_not_found' });
  if (sp.uid !== (req.user ? req.user.uid : null)) return res.status(403).json({ error: 'forbidden' });
  if (sp.ended) return res.status(410).json({ error: 'sprint_ended' });

  const now = Date.now();
  if (now > sp.startedAt + SPRINT_MS + GRACE_MS) return res.status(410).json({ error: 'sprint_expired' });
  if (!sp.cur || seq !== sp.cur.seq) return res.status(409).json({ error: 'stale_question' });
  if (typeof answer !== (sp.mode === 'flash' ? 'number' : 'boolean')) return res.status(400).json({ error: 'bad_answer' });

  const q = sp.cur;
  const reactionMs = Math.max(0, Math.min(5000, now - q.issuedAt));
  const correct = sp.mode === 'flash' ? answer === q.termId : answer === q.truth;
  const credible = reactionMs >= MIN_REACTION_MS;

  sp.total += 1;
  sp.reactions.push(reactionMs);

  let points = 0, capped = false;
  if (correct && credible) {
    sp.correct += 1;
    const raw = 20 + (reactionMs < 1500 ? 15 : 5) + Math.min(25, sp.combo * 5);
    sp.combo += 1;
    if (req.user) {
      const r = awardPoints(req.user, raw);
      points = r.allowed;
      capped = r.capped;
    } else {
      points = raw; // guest: shown but never stored
    }
    sp.points += points;
  } else {
    sp.combo = 1;
  }

  if (req.user) {
    const u = req.user;
    if (correct && credible) { addUnique(u.mastered, q.termId); removeVal(u.weak, q.termId); sp.weak.delete(q.termId); }
    else { addUnique(u.weak, q.termId); sp.weak.add(q.termId); }
    u.reactions.push(reactionMs);
    if (u.reactions.length > 20) u.reactions.shift();
    save();
  }

  const timeUp = now >= sp.startedAt + SPRINT_MS;
  res.json({
    correct, points, capped, combo: sp.combo, reactionMs,
    correctTermId: q.termId, truth: q.truth,
    sessionPoints: sp.points, total: sp.total, correctCount: sp.correct,
    delayMs: FEEDBACK_MS,
    question: timeUp ? null : newQuestion(sp, FEEDBACK_MS)
  });
});

app.post('/api/sprint/finish', optionalAuth, (req, res) => {
  const sp = sprints.get(req.body && req.body.sprintId);
  if (!sp) return res.status(404).json({ error: 'sprint_not_found' });
  if (sp.uid !== (req.user ? req.user.uid : null)) return res.status(403).json({ error: 'forbidden' });
  const summary = endSprint(sp, req.user);
  res.json({ summary, me: req.user ? publicMe(req.user) : null });
});

/* ------------------------------ payments ---------------------------- */
const PRODUCT = 'pro_pass';

function paymentMatchesProduct(p) {
  return p && p.metadata && p.metadata.product === PRODUCT && sameAmount(p.amount, PRO_PRICE);
}

async function finalizePayment(p, txid, grant) {
  const id = p.identifier;
  const rec = db.payments[id];
  if (rec && rec.status === 'completed') return { already: true };
  if (!p.status || !p.status.developer_completed) {
    await piFetch('/payments/' + encodeURIComponent(id) + '/complete', {
      method: 'POST', auth: piKey(), body: { txid }
    });
  }
  db.payments[id] = {
    uid: p.user_uid, product: PRODUCT, amount: p.amount, txid,
    status: 'completed', granted: !!grant, completedAt: Date.now()
  };
  if (grant) {
    const u = upsertUser(p.user_uid);
    u.pro = true;
    pushLedger(u, { t: 'pro_pass', amt: Number(p.amount) });
  }
  save();
  return { already: false };
}

app.post('/api/payments/approve', requireAuth, requirePiKey, rateLimit('pay', 30, 60000), async (req, res) => {
  const id = req.body && req.body.paymentId;
  if (!validId(id)) return res.status(400).json({ error: 'bad_request' });
  try {
    const p = await piFetch('/payments/' + encodeURIComponent(id), { auth: piKey() });
    if (p.user_uid !== req.user.uid) return res.status(403).json({ error: 'wrong_user' });
    if (!paymentMatchesProduct(p)) return res.status(400).json({ error: 'bad_product' });
    if (req.user.pro) {
      await piFetch('/payments/' + encodeURIComponent(id) + '/cancel', { method: 'POST', auth: piKey() }).catch(() => {});
      return res.status(409).json({ error: 'already_pro' });
    }
    const rec = db.payments[id];
    if (rec && rec.status === 'completed') return res.status(409).json({ error: 'already_completed' });
    db.payments[id] = rec || { uid: req.user.uid, product: PRODUCT, amount: p.amount, status: 'approved', createdAt: Date.now() };
    await piFetch('/payments/' + encodeURIComponent(id) + '/approve', { method: 'POST', auth: piKey() });
    save();
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ error: 'pi_api_error' });
  }
});

app.post('/api/payments/complete', requireAuth, requirePiKey, rateLimit('pay', 30, 60000), async (req, res) => {
  const { paymentId: id, txid } = req.body || {};
  if (!validId(id) || typeof txid !== 'string' || txid.length < 8 || txid.length > 200) {
    return res.status(400).json({ error: 'bad_request' });
  }
  try {
    const p = await piFetch('/payments/' + encodeURIComponent(id), { auth: piKey() });
    if (p.user_uid !== req.user.uid) return res.status(403).json({ error: 'wrong_user' });
    if (!paymentMatchesProduct(p)) return res.status(400).json({ error: 'bad_product' });
    const rec = db.payments[id];
    if (!rec) return res.status(400).json({ error: 'not_approved' }); // must have gone through our approve step
    await finalizePayment(p, txid, true);
    res.json({ ok: true, me: publicMe(db.users[req.user.uid]) });
  } catch (e) {
    res.status(502).json({ error: 'pi_api_error' });
  }
});

// Called by the Pi SDK (onIncompletePaymentFound) during sign-in.
// We never trust the client body: the payment is re-fetched from the Pi API.
app.post('/api/payments/incomplete', requirePiKey, rateLimit('incomplete', 20, 60000), async (req, res) => {
  const id = req.body && req.body.payment && req.body.payment.identifier;
  if (!validId(id)) return res.status(400).json({ error: 'bad_request' });
  try {
    const p = await piFetch('/payments/' + encodeURIComponent(id), { auth: piKey() });
    const txid = p.transaction && p.transaction.txid;
    if (txid) {
      await finalizePayment(p, txid, paymentMatchesProduct(p));
    } else if (!(p.status && (p.status.cancelled || p.status.user_cancelled))) {
      await piFetch('/payments/' + encodeURIComponent(id) + '/cancel', { method: 'POST', auth: piKey() });
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ error: 'pi_api_error' });
  }
});

/* ------------------------------- static ----------------------------- */
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '5m' }));
app.use('/api', (req, res) => res.status(404).json({ error: 'not_found' }));
app.use((err, req, res, next) => res.status(400).json({ error: 'bad_request' }));

app.listen(PORT, () => console.log('LexiPulse Pi listening on :' + PORT + (PI_SANDBOX ? ' (sandbox)' : '')));
